
CREATE TRIGGER delCusKey ON Custodian
FOR delete
AS
declare @a varchar(20); 
select @a = Id from deleted;   
delete from CustodianKey where Id = @a

go

