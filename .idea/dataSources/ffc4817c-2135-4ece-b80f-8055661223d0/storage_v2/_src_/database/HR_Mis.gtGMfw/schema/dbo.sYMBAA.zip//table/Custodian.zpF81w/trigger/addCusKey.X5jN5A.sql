

CREATE TRIGGER addCusKey ON Custodian
FOR insert
AS
declare @a varchar(20); 
select @a = Id from inserted;   
insert into CustodianKey values(@a,@a,'1');
go

